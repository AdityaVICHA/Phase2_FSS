﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Common;
using FlightSchedularSystem_Entities;
using FlightSchedularSystem_Exception;
using System.Data.SqlClient;

namespace FlightSchedularSystem_DAL
{
    public class FlightDAL
    {
        SqlConnection sqlcon = new SqlConnection("Server=NDAMSSQL\\SQLILEARN;Database=Training_13Aug19_Pune;User Id=sqluser;Password=sqluser");
        public static List<FlightEntities> flightList = new List<FlightEntities>();

        public bool AddFlightDAL(FlightEntities newFlight)
        {
            bool flightAdded = false;
            try
            {
                sqlcon.Open();
                SqlCommand sqlcmd = new SqlCommand("Insert_Flightinfo4", sqlcon);
                sqlcmd.CommandType = CommandType.StoredProcedure;

                sqlcmd.Parameters.AddWithValue("@ScheduledTime", newFlight.Departure);
                sqlcmd.Parameters.AddWithValue("@TerminalName", newFlight.TerminalName);
                sqlcmd.Parameters.AddWithValue("@AirportName", newFlight.AirportName);
                sqlcmd.Parameters.AddWithValue("@ContactNo", newFlight.ContactNo);
                sqlcmd.Parameters.AddWithValue("@Name", newFlight.Name);
                sqlcmd.Parameters.AddWithValue("@Destination", newFlight.Destination);
                sqlcmd.Parameters.AddWithValue("@GateNo", newFlight.GateNo);
                sqlcmd.Parameters.AddWithValue("@StatusId", newFlight.Status);

                //execute command
                int irowsaffected = sqlcmd.ExecuteNonQuery();
                
                flightAdded = true;
            }
            catch (SystemException ex)
            {
                throw new FlightException(ex.Message);
            }
            return flightAdded;
        }


        //        public bool UpdateFlightDAL(FlightEntities updateFlight)
        //        {
        //            bool flightUpdated = false;
        //            try
        //            {
        //                for (int i = 0; i < flightList.Count; i++)
        //                {
        //                    if (flightList[i].FlightNo == updateFlight.FlightNo)
        //                    {
        //                        //updateFlight.Name = flightList[i].Name;
        //                        updateFlight.Destination = flightList[i].Destination;
        //                        updateFlight.Terminal = flightList[i].Terminal;
        //                        updateFlight.GateNo = flightList[i].GateNo;
        //                        updateFlight.Departure = flightList[i].Departure;
        //                        updateFlight.Status = flightList[i].Status;

        //                        flightUpdated = true;
        //                    }

        //                }
        //            }
        //            catch (SystemException ex)
        //            {
        //                throw new FlightException(ex.Message);
        //            }
        //            return flightUpdated;
        //        }

        //        public bool DeleteFlightDAL(string deleteFlightNo)
        //        {
        //            bool flightDeleted = false;
        //            try
        //            {
        //                FlightEntities deleteFlight = flightList.Find(flight => flight.FlightNo == deleteFlightNo);

        //                if (deleteFlight != null)
        //                {
        //                    flightList.Remove(deleteFlight);
        //                    flightDeleted = true;
        //                }
        //            }
        //            catch (DbException ex)
        //            {
        //                throw new FlightException(ex.Message);
        //            }
        //            return flightDeleted;
        //        }

        //        public FlightEntities SearchFlightDAL(string searchFlightNo)
        //        {
        //            FlightEntities searchFlight = null;
        //            try
        //            {
        //                searchFlight = flightList.Find(flight => flight.FlightNo == searchFlightNo);
        //            }
        //            catch(SystemException ex)
        //            {
        //                throw new FlightException(ex.Message);
        //            }
        //            return searchFlight;
        //        }

        //        public List<FlightEntities> GetAllFlightsDAL()
        //        {
        //            return flightList;
        //        }
    }
}
