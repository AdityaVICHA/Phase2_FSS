﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightSchedularSystem_Entities
{
    public class FlightEntities
    {
        public string FlightNo { get; set; }

        public string Name { get; set; }

        public string Destination { get; set; }

        public string GateNo { get; set; }

        public string TerminalName { get; set; }

        public string AirportName { get; set; }

        public int ContactNo { get; set; }

        public DateTime Departure { get; set; }

        public int Status { get; set; }

    }
    
    
}
