﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using FlightSchedularSystem_Entities;
using FlightSchedularSystem_BusinessLayer;
using System.Data.SqlClient;
using Xceed.Wpf;

namespace FMS_Pl
{
    /// <summary>
    /// Interaction logic for AddFlight.xaml
    /// </summary>
    public partial class AddFlight : Window
    {
        public AddFlight()
        {
            SqlConnection sqlcon = new SqlConnection("Server=NDAMSSQL\\SQLILEARN;Database=Training_13Aug19_Pune;User Id=sqluser;Password=sqluser");
            SqlCommand sqlCmd = new SqlCommand("SELECT Id,Description FROM FlightStatus_bk", sqlcon);
            sqlcon.Open();
            SqlDataReader sqlReader = sqlCmd.ExecuteReader();
            ComboBox comb = new ComboBox();
            

            while (sqlReader.Read())
            {


                comb.Items.Add(new
                {
                    Text = sqlReader["Description"].ToString(),
                    Value = sqlReader["Id"].ToString()

                });
            }
            sqlReader.Close();
            InitializeComponent();
            }


        

        private void Btn_AddFlight(object sender, RoutedEventArgs e)
        {
            FlightEntities flight = new FlightEntities();

            flight.Departure = DateTime.Parse(DTP_DateScheduled.Text);
            flight.TerminalName = TxtTerminal.Text;
            flight.AirportName = TxtAirport.Text;
            flight.ContactNo = Convert.ToInt32(TxtContact.Text);
            flight.Name = TxtFlightName.Text;
            flight.Destination = TxtDesitination.Text;
            flight.GateNo = TxtGateNo.Text;
            flight.Status = int.Parse(TxtStatusId.Text);
            bool flightAdded = FlightBL.AddFlightBL(flight);
            if (flightAdded)
                MessageBox.Show("Flight Added Successfully !");
            else
                MessageBox.Show("Flight Not Added.");
        }

        private void TxtScheduledTime_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
    
